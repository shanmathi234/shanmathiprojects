document.addEventListener('DOMContentLoaded', function () {
    let currentPage = 1;

    function changePage() {
        currentPage = (currentPage % 4) + 1;
        updatePages();
    }

    function updatePages() {
        for (let i = 1; i <= 4; i++) {
            const page = document.getElementById('page' + i);
            const rotation = (i - currentPage) * 90;
            page.style.transform = 'rotateY(' + rotation + 'deg)';
        }
    }

    setInterval(changePage, 10000); // Change photo every 30 seconds
});
